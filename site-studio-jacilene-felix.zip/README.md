# Studio de Beleza AI - Jacilene Félix

![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)
![Vite](https://img.shields.io/badge/Vite-646CFF?style=for-the-badge&logo=vite&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)
![Gemini API](https://img.shields.io/badge/Gemini_API-4285F4?style=for-the-badge&logo=google&logoColor=white)

Um website para um estúdio de beleza de luxo, com assistentes de IA integrados para agendamento, consultas virtuais e demonstrações de serviços usando a API Gemini.

**[Demonstração ao Vivo](https://miqueiasilva.github.io/site-studio-jacilene-felix/)**

---

## ✨ Funcionalidades

- **Página de Serviços Detalhada:** Informações completas sobre cada tratamento oferecido.
- **Equipe de Profissionais:** Conheça os especialistas do estúdio.
- **Galeria de Resultados:** Veja fotos de antes e depois de clientes reais.
- **Contato e Localização:** Formulário de contato, informações e mapa integrado.
- **Design Responsivo:** Totalmente funcional em desktops, tablets e celulares.
- **🤖 Laboratório de IA:**
  - **Simulador Virtual:** Envie uma foto e use a IA para visualizar alterações estéticas (ex: sobrancelhas, lábios).
  - **Consulta Personalizada:** Receba recomendações de tratamento detalhadas com base em suas necessidades, usando o modo de pensamento avançado do Gemini.
- **💬 ChatBot com IA:**
  - **Assistente de Texto:** Converse com uma IA para tirar dúvidas sobre serviços e agendamentos.
  - **Assistente de Voz:** Interaja com a assistente usando sua voz para uma experiência de conversação natural.

## 🛠️ Tecnologias Utilizadas

- **Frontend:** React, TypeScript, Vite, Tailwind CSS
- **IA:** Google Gemini API (`@google/genai`)
- **Hospedagem:** GitHub Pages

## 🚀 Começando

Siga as instruções abaixo para executar o projeto em sua máquina local.

### Pré-requisitos

- Node.js (versão 20.x ou superior)
- npm (geralmente vem com o Node.js)
- Uma API Key da [Google AI Studio](https://aistudio.google.com/).

### Instalação

1.  **Clone o repositório:**
    ```bash
    git clone https://github.com/miqueiasilva/site-studio-jacilene-felix.git
    cd site-studio-jacilene-felix
    ```

2.  **Instale as dependências:**
    ```bash
    npm install
    ```

3.  **Configure a API Key:**
    - Crie um arquivo chamado `.env` na raiz do projeto.
    - Adicione sua API Key do Google Gemini a ele:
      ```
      API_KEY="SUA_API_KEY_AQUI"
      ```
    *Este arquivo é ignorado pelo Git para manter sua chave segura.*

4.  **Inicie o servidor de desenvolvimento:**
    ```bash
    npm run dev
    ```

O aplicativo estará disponível em `http://localhost:5173` (ou outra porta indicada no terminal).

## 🖼️ Telas da Aplicação

*(Adicione aqui capturas de tela do seu aplicativo para demonstrar o visual e as funcionalidades.)*

---
Desenvolvido com ❤️ e IA por Miquéias Silva.