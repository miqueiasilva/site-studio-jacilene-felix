import React, { useState } from 'react';
import * as geminiService from '../services/geminiService';

const AILab: React.FC = () => {
    return (
        <section id="ailab" className="py-20 bg-white">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-bold fancy-font text-[#3a322c]">Nosso Laboratório de IA</h2>
                    <p className="text-[#745b47] mt-2">Experimente o futuro da consultoria de beleza com nossas ferramentas de IA.</p>
                </div>
                <div className="flex justify-center">
                    <div className="w-full max-w-3xl">
                        <ComplexConsultation />
                    </div>
                </div>
            </div>
        </section>
    );
};


const ComplexConsultation: React.FC = () => {
    const [prompt, setPrompt] = useState('Meu tipo de pele é oleosa e tenho 30 anos. Quero um plano de tratamento completo para os próximos 6 meses, focando em micropigmentação de sobrancelhas e rejuvenescimento da pele. Quais serviços você recomenda e em que ordem?');
    const [response, setResponse] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleGenerate = async () => {
        if (!prompt) return;
        setLoading(true);
        setError('');
        setResponse('');
        try {
            const result = await geminiService.getComplexConsultation(prompt);
            setResponse(result);
        } catch (e) {
            setError('Falha ao gerar a consulta. Tente novamente.');
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    return (
        <AIFeature title="Consulta Personalizada (Modo Pensamento)" description="Faça perguntas complexas e receba um plano detalhado. A IA usará seu poder máximo de raciocínio.">
            <label htmlFor="prompt-complex-consultation" className="sr-only">Descreva suas necessidades em detalhes:</label>
            <textarea
                id="prompt-complex-consultation"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Descreva suas necessidades em detalhes..."
                className="w-full p-2 border rounded-lg bg-white mb-4"
                rows={5}
            />
            <button onClick={handleGenerate} disabled={loading} className="w-full bg-[#745b47] text-white px-6 py-3 rounded-full hover:bg-[#5f493a] transition transform active:scale-95 disabled:bg-gray-400 font-semibold">
                {loading ? 'Pensando...' : 'Obter Consulta'}
            </button>
            <OutputArea loading={loading} error={error}>
                 {response && <div className="prose max-w-none p-4 bg-gray-50 rounded-lg whitespace-pre-wrap">{response}</div>}
            </OutputArea>
        </AIFeature>
    );
};

// --- Helper Components ---

const AIFeature: React.FC<{title: string, description: string, children: React.ReactNode}> = ({ title, description, children }) => (
    <div className="bg-[#e9e2d9] p-6 sm:p-8 rounded-2xl shadow-lg h-full flex flex-col">
        <h3 className="text-2xl sm:text-3xl font-bold fancy-font text-[#3a322c] mb-2">{title}</h3>
        <p className="text-[#745b47] mb-6">{description}</p>
        <div className="flex-grow flex flex-col">{children}</div>
    </div>
);

const OutputArea: React.FC<{loading: boolean, error: string, loadingMessage?: string, children: React.ReactNode}> = ({ loading, error, loadingMessage, children }) => (
    <div className="mt-4 border rounded-lg bg-gray-50 flex-grow flex items-center justify-center min-h-[150px]" aria-live="polite">
        {loading ? <Spinner message={loadingMessage} /> :
         error ? <ErrorMessage message={error} /> :
         children ? <div className="w-full h-full">{children}</div> : null
        }
    </div>
);

const Spinner: React.FC<{message?: string}> = ({message}) => (
    <div className="text-center p-4">
        <i className="fas fa-spinner fa-spin text-3xl text-[#745b47]"></i>
        {message && <p className="mt-2 text-sm text-[#745b47]">{message}</p>}
    </div>
);

const ErrorMessage: React.FC<{message: string}> = ({message}) => <p className="text-red-600 text-center p-4" role="alert">{message}</p>;

export default AILab;