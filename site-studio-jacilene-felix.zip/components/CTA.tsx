import React from 'react';

const CTA: React.FC = () => {
    return (
        <section className="bg-[#f9f6f2] py-20">
            <div className="container mx-auto px-6 text-center">
                <h2 className="text-4xl md:text-5xl font-bold fancy-font text-[#3a322c] mb-4">Pronta para Realçar sua Beleza Natural?</h2>
                <p className="text-[#745b47] max-w-2xl mx-auto mb-8">
                    Agende sua consulta e descubra como podemos transformar seu olhar com naturalidade e sofisticação
                </p>
                <div className="flex justify-center space-x-4">
                    <a href="https://www.salao99.com.br/studio-jacilene-felix" target="_blank" rel="noopener noreferrer" className="bg-white border border-[#745b47] text-[#745b47] px-8 py-3 rounded-full hover:bg-[#745b47] hover:text-white transition transform active:scale-95 flex items-center gap-2">
                        <i className="fas fa-calendar-alt"></i> Agendar Consulta
                    </a>
                    <a href="https://api.whatsapp.com/send/?phone=5581995685910" target="_blank" rel="noopener noreferrer" className="bg-[#745b47] text-white px-8 py-3 rounded-full hover:bg-[#5f493a] transition transform active:scale-95 flex items-center gap-2">
                        <i className="fab fa-whatsapp"></i> WhatsApp IA
                    </a>
                </div>
            </div>
        </section>
    );
}

export default CTA;