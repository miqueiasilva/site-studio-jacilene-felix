import React, { useState, useRef, useEffect } from 'react';
import { careTips } from '../constants';
import { CareTip } from '../types';

const CareTipModal: React.FC<{ tip: CareTip, onClose: () => void }> = ({ tip, onClose }) => {
    const modalRef = useRef<HTMLDivElement>(null);

    // Close modal on escape key press
    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        document.addEventListener('keydown', handleKeyDown);
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [onClose]);

    // Trap focus within the modal
    useEffect(() => {
        const modalElement = modalRef.current;
        if (!modalElement) return;

        const focusableElements = modalElement.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

        firstElement?.focus();

        const trapFocus = (e: KeyboardEvent) => {
            if (e.key !== 'Tab') return;

            if (e.shiftKey) { // Shift + Tab
                if (document.activeElement === firstElement) {
                    lastElement.focus();
                    e.preventDefault();
                }
            } else { // Tab
                if (document.activeElement === lastElement) {
                    firstElement.focus();
                    e.preventDefault();
                }
            }
        };
        modalElement.addEventListener('keydown', trapFocus);
        return () => {
            modalElement.removeEventListener('keydown', trapFocus);
        }
    }, []);


    return (
        <div ref={modalRef} className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="care-tip-title">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg flex flex-col overflow-hidden animate-fade-in-up" onClick={(e) => e.stopPropagation()}>
                <header className="bg-[#3a322c] text-white p-4 flex justify-between items-center">
                    <h3 id="care-tip-title" className="text-xl font-semibold fancy-font">{tip.title}</h3>
                    <button onClick={onClose} className="text-2xl hover:opacity-80 transition-transform active:scale-95" aria-label="Fechar modal">&times;</button>
                </header>
                <div className="p-6 overflow-y-auto">
                    <p className="text-[#745b47] mb-6">{tip.description}</p>
                    <ul className="space-y-3">
                        {tip.details.map((detail, index) => (
                            <li key={index} className="flex items-start gap-3 text-[#3a322c]">
                                <i className="fas fa-check-circle text-[#745b47] mt-1"></i>
                                <span>{detail}</span>
                            </li>
                        ))}
                    </ul>
                </div>
                 <footer className="p-4 border-t bg-gray-50 text-right">
                    <button onClick={onClose} className="bg-[#745b47] text-white px-6 py-2 rounded-full hover:bg-[#5f493a] transition transform active:scale-95">
                        Fechar
                    </button>
                </footer>
            </div>
             <style>{`
                @keyframes fade-in-up {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                .animate-fade-in-up {
                    animation: fade-in-up 0.3s ease-out forwards;
                }
            `}</style>
        </div>
    );
};


const CareTipCard: React.FC<{ tip: CareTip, onReadMore: () => void }> = ({ tip, onReadMore }) => (
    <div className="bg-white rounded-2xl p-6 shadow-lg transition-transform hover:scale-105 flex flex-col">
        <h3 className="text-xl font-bold fancy-font text-[#3a322c] mb-2">{tip.title}</h3>
        <p className="text-sm text-[#745b47] mb-4 flex-grow">{tip.description}</p>
        <button onClick={onReadMore} className="text-[#745b47] font-semibold hover:text-[#3a322c] text-left mt-auto transition-transform hover:translate-x-1">
            Ler mais →
        </button>
    </div>
);

const CareTips: React.FC = () => {
    const [selectedTip, setSelectedTip] = useState<CareTip | null>(null);

    const handleReadMore = (tip: CareTip) => {
        setSelectedTip(tip);
    };

    const handleCloseModal = () => {
        setSelectedTip(null);
    };

    useEffect(() => {
        if (selectedTip) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';
        }
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [selectedTip]);

    return (
        <section id="care-tips" className="py-20 bg-[#f9f6f2]">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-bold fancy-font text-[#3a322c]">Dicas de Cuidados</h2>
                    <p className="text-[#745b47] mt-2">Maximize e mantenha seus resultados com nossas dicas de especialistas.</p>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {careTips.map((tip, index) => (
                        <CareTipCard key={index} tip={tip} onReadMore={() => handleReadMore(tip)} />
                    ))}
                </div>
            </div>
            {selectedTip && <CareTipModal tip={selectedTip} onClose={handleCloseModal} />}
        </section>
    );
};

export default CareTips;
