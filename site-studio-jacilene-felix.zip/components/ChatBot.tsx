import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChatMessage } from '../types';
import * as geminiService from '../services/geminiService';
import { GoogleGenAI, LiveSession, LiveServerMessage, Modality, Blob, Chat } from '@google/genai';

// --- Audio Helper Functions ---
function encode(bytes: Uint8Array): string {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function decode(base64: string): Uint8Array {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
        const channelData = buffer.getChannelData(channel);
        for (let i = 0; i < frameCount; i++) {
            channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
        }
    }
    return buffer;
}

// FIX: Added createBlob function for efficient audio data conversion as per Gemini API guidelines.
function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}


const ChatBot: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { role: 'model', content: 'Olá! Como posso ajudar você a realçar sua beleza hoje?' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isListening, setIsListening] = useState(false);
    
    const chatRef = useRef<Chat | null>(null);
    const liveSessionPromise = useRef<Promise<LiveSession> | null>(null);
    const mediaStream = useRef<MediaStream | null>(null);
    const audioContext = useRef<AudioContext | null>(null);
    const scriptProcessor = useRef<ScriptProcessorNode | null>(null);
    const outputAudioContext = useRef<AudioContext | null>(null);
    const outputGainNode = useRef<GainNode | null>(null); // FIX: Added GainNode for output audio.
    const nextStartTime = useRef(0);
    const sources = useRef(new Set<AudioBufferSourceNode>());

    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatRef.current = geminiService.startChat('Você é uma assistente virtual do Studio Jacilene Félix. Seja amigável, profissional e ajude os clientes com informações sobre serviços, agendamentos e cuidados.');
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim()) return;

        const userMessage: ChatMessage = { role: 'user', content: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            if (!chatRef.current) throw new Error("Chat not initialized");
            const response = await geminiService.sendMessageToChat(chatRef.current, input);
            const modelMessage: ChatMessage = { role: 'model', content: response.text };
            setMessages(prev => [...prev, modelMessage]);
        } catch (error) {
            console.error('Error sending message:', error);
            const errorMessage: ChatMessage = { role: 'system', content: 'Desculpe, ocorreu um erro. Tente novamente.' };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    const startListening = async () => {
        if (isListening) return;
        setIsListening(true);
        setMessages(prev => [...prev, { role: 'system', content: 'Ouvindo... Fale agora.' }]);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
            
            outputAudioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            // FIX: Use a GainNode for output audio as recommended by guidelines.
            outputGainNode.current = outputAudioContext.current.createGain();
            outputGainNode.current.connect(outputAudioContext.current.destination);

            liveSessionPromise.current = ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                callbacks: {
                    onopen: async () => {
                        console.log('Live session opened.');
                        mediaStream.current = await navigator.mediaDevices.getUserMedia({ audio: true });
                        audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                        const source = audioContext.current.createMediaStreamSource(mediaStream.current);
                        scriptProcessor.current = audioContext.current.createScriptProcessor(4096, 1, 1);

                        scriptProcessor.current.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            // FIX: Use the efficient createBlob helper function.
                            const pcmBlob: Blob = createBlob(inputData);
                            liveSessionPromise.current?.then((session) => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };
                        source.connect(scriptProcessor.current);
                        scriptProcessor.current.connect(audioContext.current.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData.data;
                        if (base64Audio && outputAudioContext.current && outputGainNode.current) {
                            nextStartTime.current = Math.max(nextStartTime.current, outputAudioContext.current.currentTime);
                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext.current, 24000, 1);
                            const sourceNode = outputAudioContext.current.createBufferSource();
                            sourceNode.buffer = audioBuffer;
                            // FIX: Connect to the GainNode instead of destination directly.
                            sourceNode.connect(outputGainNode.current);
                            sourceNode.addEventListener('ended', () => sources.current.delete(sourceNode));
                            
                            sourceNode.start(nextStartTime.current);
                            nextStartTime.current += audioBuffer.duration;
                            sources.current.add(sourceNode);
                        }

                        if (message.serverContent?.outputTranscription) {
                            // For simplicity, we'll just log transcription. A more complex UI could display it live.
                            console.log('Model transcription:', message.serverContent.outputTranscription.text);
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error('Live session error:', e);
                        setMessages(prev => [...prev, { role: 'system', content: `Erro na conexão de voz: ${e.message}` }]);
                        stopListening();
                    },
                    onclose: (e: CloseEvent) => {
                        console.log('Live session closed.');
                        stopListening();
                    },
                },
                config: {
                    responseModalities: [Modality.AUDIO],
                    outputAudioTranscription: {},
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
                },
            });
        } catch (err) {
            console.error("Failed to start listening:", err);
            setMessages(prev => [...prev, { role: 'system', content: 'Não foi possível acessar o microfone.' }]);
            setIsListening(false);
        }
    };
    
    const stopListening = useCallback(() => {
        if (!isListening) return;
        setIsListening(false);

        liveSessionPromise.current?.then(session => session.close());
        liveSessionPromise.current = null;
        
        mediaStream.current?.getTracks().forEach(track => track.stop());
        scriptProcessor.current?.disconnect();
        audioContext.current?.close();

        for (const source of sources.current.values()) {
            source.stop();
        }
        sources.current.clear();
        // FIX: Disconnect GainNode and close audio context on stop.
        outputGainNode.current?.disconnect();
        outputAudioContext.current?.close();
        nextStartTime.current = 0;
        
        setMessages(prev => [...prev, { role: 'system', content: 'Gravação parada.' }]);
    }, [isListening]);


    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-0 sm:p-4">
            <div className="bg-white shadow-2xl w-full h-full sm:rounded-2xl sm:max-w-lg sm:h-[80vh] flex flex-col overflow-hidden">
                <header className="bg-[#3a322c] text-white p-4 flex justify-between items-center">
                    <h3 className="text-lg font-semibold fancy-font">Assistente Virtual</h3>
                    <button onClick={onClose} className="text-xl" aria-label="Fechar chat">&times;</button>
                </header>
                <div className="flex-1 p-4 overflow-y-auto bg-[#f9f6f2] space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {msg.role === 'system' ? (
                                <p className="text-center text-sm text-gray-500 italic w-full">{msg.content}</p>
                            ) : (
                                <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${msg.role === 'user' ? 'bg-[#745b47] text-white rounded-br-none' : 'bg-[#e9e2d9] text-[#3a322c] rounded-bl-none'}`}>
                                    {msg.content}
                                </div>
                            )}
                        </div>
                    ))}
                    {isLoading && <div className="flex justify-start"><div className="p-3 rounded-2xl bg-[#e9e2d9] text-[#3a322c] rounded-bl-none">Digitando...</div></div>}
                    <div ref={messagesEndRef} />
                </div>
                <footer className="p-4 border-t bg-white">
                    <div className="flex items-center gap-2">
                         <label htmlFor="chat-input" className="sr-only">Digite sua mensagem</label>
                        <input
                            id="chat-input"
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSend()}
                            placeholder="Digite sua mensagem..."
                            className="flex-1 p-2 border rounded-full focus:outline-none focus:ring-2 focus:ring-[#745b47]"
                            disabled={isLoading || isListening}
                        />
                        <button 
                          onClick={isListening ? stopListening : startListening} 
                          className={`p-3 w-12 h-12 rounded-full transition-all transform active:scale-95 text-white ${isListening ? 'bg-red-500' : 'bg-[#745b47] hover:bg-[#5f493a]'}`}
                          aria-label={isListening ? 'Parar gravação' : 'Gravar mensagem de voz'}
                        >
                            <i className={`fas ${isListening ? 'fa-stop' : 'fa-microphone'}`}></i>
                        </button>
                        <button 
                          onClick={handleSend} 
                          disabled={isLoading || isListening} 
                          className="p-3 w-12 h-12 rounded-full bg-[#745b47] text-white hover:bg-[#5f493a] transition transform active:scale-95 disabled:bg-gray-400"
                          aria-label="Enviar mensagem"
                        >
                            <i className="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </footer>
            </div>
        </div>
    );
};

export default ChatBot;