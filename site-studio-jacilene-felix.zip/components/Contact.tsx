import React, { useState, FormEvent } from 'react';

const Contact: React.FC = () => {
    const [formData, setFormData] = useState({
        name: '',
        whatsapp: '',
        service: '',
        message: '',
    });
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [isLoading, setIsLoading] = useState(false);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const validate = () => {
        const newErrors: { [key: string]: string } = {};
        if (!formData.name.trim()) newErrors.name = 'O nome é obrigatório.';
        if (!formData.whatsapp.trim()) {
            newErrors.whatsapp = 'O WhatsApp é obrigatório.';
        } else if (!/^\s*(\(?\d{2}\)?\s*)?(\d{4,5}-?\d{4})\s*$/.test(formData.whatsapp)) {
             newErrors.whatsapp = 'Formato de WhatsApp inválido. Use (XX) XXXXX-XXXX.';
        }
        if (!formData.service || formData.service === 'Selecione um serviço') {
            newErrors.service = 'Selecione um serviço de interesse.';
        }
        if (!formData.message.trim()) {
            newErrors.message = 'A mensagem é obrigatória.';
        } else if (formData.message.length > 500) {
            newErrors.message = 'A mensagem não pode exceder 500 caracteres.';
        }
        return newErrors;
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        const newErrors = validate();
        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
            setIsSubmitted(false);
        } else {
            setErrors({});
            setIsLoading(true);
            // Simulate API call
            setTimeout(() => {
                setIsLoading(false);
                setIsSubmitted(true);
                console.log('Form data submitted:', formData);
                // setFormData({ name: '', whatsapp: '', service: '', message: '' }); // Optionally clear form
            }, 1000);
        }
    };


    return (
        <section id="contato" className="py-20 bg-white">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-bold fancy-font text-[#3a322c]">Entre em Contato</h2>
                    <p className="text-[#745b47] mt-2">Estamos prontas para atender você. Entre em contato e tire todas as suas dúvidas</p>
                </div>
                <div className="flex flex-col lg:flex-row gap-12">
                    <div className="lg:w-1/2">
                        <div className="space-y-6">
                             <a href="https://www.google.com/maps/place/Studio+Jacilene+F%C3%A9lix/@-7.9620591,-34.9114358,17z" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity block p-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#745b47]">
                                <ContactInfoItem icon="fas fa-map-marker-alt" title="Localização" lines={['R. Santina Gomes de Andrade, 04 - loja 04 - Centro', 'Igarassu - PE, 53610-272', 'Clique para ver no mapa']} />
                             </a>
                             <a href="https://api.whatsapp.com/send/?phone=5581995685910" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity block p-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#745b47]">
                               <ContactInfoItem icon="fab fa-whatsapp" title="WhatsApp" lines={['(81) 99568-5910', 'Clique para iniciar uma conversa']} />
                            </a>
                            <ContactInfoItem icon="fas fa-clock" title="Horário de Funcionamento" lines={['Segunda a Sexta: 9h às 18h', 'Sábado: 9h às 16h', 'Domingo: Fechado']} />
                        </div>
                        <div className="mt-8 rounded-2xl overflow-hidden shadow-lg">
                           <iframe
                             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3952.946351052219!2d-34.9114358!3d-7.9620591!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x7ab3ff467a840c5%3A0x7d6a5c1363e1762c!2sStudio%20Jacilene%20F%C3%A9lix!5e0!3m2!1spt-BR!2sbr"
                             width="100%" 
                             height="300" 
                             style={{border:0}} 
                             allowFullScreen={true}
                             loading="lazy" 
                             referrerPolicy="no-referrer-when-downgrade">
                           </iframe>
                        </div>
                    </div>
                    <div className="lg:w-1/2 bg-[#e9e2d9] p-8 rounded-2xl shadow-lg">
                        {isSubmitted ? (
                             <div className="text-center flex flex-col justify-center items-center h-full">
                                <i className="fas fa-check-circle text-5xl text-green-600 mb-4"></i>
                                <h3 className="text-2xl font-bold fancy-font text-[#3a322c]">Mensagem Enviada!</h3>
                                <p className="text-[#745b47] mt-2">Obrigado por entrar em contato. Retornaremos em breve!</p>
                            </div>
                        ) : (
                        <>
                            <h3 className="text-2xl font-bold fancy-font text-[#3a322c] mb-6">Envie sua Mensagem</h3>
                            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                                <div>
                                    <InputField id="name" label="Nome Completo" type="text" placeholder="Seu nome completo" value={formData.name} onChange={handleChange} required />
                                    {errors.name && <p className="text-red-600 text-xs mt-1">{errors.name}</p>}
                                </div>
                                <div>
                                    <InputField id="whatsapp" label="WhatsApp" type="tel" placeholder="(81) 99568-5910" value={formData.whatsapp} onChange={handleChange} required />
                                    {errors.whatsapp && <p className="text-red-600 text-xs mt-1">{errors.whatsapp}</p>}
                                </div>
                                <div>
                                    <label htmlFor="service" className="block text-sm font-medium text-[#745b47]">Serviço de Interesse</label>
                                    <select id="service" value={formData.service} onChange={handleChange} required className="mt-1 block w-full bg-white border border-gray-300 rounded-lg py-2 px-3 focus:outline-none focus:ring-1 focus:ring-[#745b47]">
                                        <option>Selecione um serviço</option>
                                        <option>Micropigmentação de Sobrancelhas</option>
                                        <option>Micropigmentação Labial</option>
                                        <option>Brow Lamination</option>
                                        <option>Outro</option>
                                    </select>
                                    {errors.service && <p className="text-red-600 text-xs mt-1">{errors.service}</p>}
                                </div>
                                <div>
                                    <label htmlFor="message" className="block text-sm font-medium text-[#745b47]">Mensagem</label>
                                    <textarea id="message" rows={4} value={formData.message} onChange={handleChange} required maxLength={501} className="mt-1 block w-full bg-white border border-gray-300 rounded-lg py-2 px-3 focus:outline-none focus:ring-1 focus:ring-[#745b47]" placeholder="Conte-nos mais sobre suas necessidades..."></textarea>
                                    <p className="text-xs text-right text-gray-500 mt-1">{formData.message.length} / 500</p>
                                    {errors.message && <p className="text-red-600 text-xs mt-1">{errors.message}</p>}
                                </div>
                                <button type="submit" disabled={isLoading} className="w-full bg-[#745b47] text-white py-3 rounded-full hover:bg-[#5f493a] transition transform active:scale-95 font-semibold disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                                     {isLoading && <i className="fas fa-spinner fa-spin"></i>}
                                     {isLoading ? 'Enviando...' : 'Enviar Mensagem'}
                                </button>
                            </form>
                        </>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
};

const ContactInfoItem: React.FC<{icon: string, title: string, lines: string[]}> = ({ icon, title, lines }) => (
    <div className="flex items-start gap-4">
        <div className="bg-[#745b47] text-white rounded-full w-12 h-12 flex-shrink-0 flex items-center justify-center">
            <i className={icon}></i>
        </div>
        <div>
            <h4 className="font-bold text-[#3a322c]">{title}</h4>
            {lines.map((line, index) => (
                 <p key={index} className="text-sm text-[#745b47]">{line}</p>
            ))}
        </div>
    </div>
);

const InputField: React.FC<{id: string, label: string, type: string, placeholder: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, required?: boolean}> = ({ id, label, type, placeholder, value, onChange, required }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-[#745b47]">{label}</label>
        <input type={type} id={id} placeholder={placeholder} value={value} onChange={onChange} required={required} className="mt-1 block w-full bg-white border border-gray-300 rounded-lg py-2 px-3 focus:outline-none focus:ring-1 focus:ring-[#745b47]" />
    </div>
);

export default Contact;