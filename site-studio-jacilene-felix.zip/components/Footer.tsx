import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="bg-[#3a322c] text-[#e9e2d9] py-12">
            <div className="container mx-auto px-6">
                <div className="grid md:grid-cols-4 gap-8">
                    <div className="md:col-span-1">
                        <div className="flex items-center gap-3 mb-4">
                            <img src="https://i.ibb.co/CsTQHWpN/Sem-T-tulo-1-removebg-preview.png" alt="Studio Jacilene Félix Logo" className="h-8" loading="lazy" decoding="async" width="32" height="32" />
                            <h3 className="text-xl font-bold fancy-font">Studio Jacilene Félix</h3>
                        </div>
                        <p className="text-sm mb-4">Especialistas em beleza natural e micropigmentação com atendimento premium e resultados excepcionais.</p>
                        <div className="flex space-x-4">
                            <a href="#" className="hover:text-white"><i className="fab fa-instagram"></i></a>
                            <a href="#" className="hover:text-white"><i className="fab fa-facebook-f"></i></a>
                            <a href="https://api.whatsapp.com/send/?phone=5581995685910" target="_blank" rel="noopener noreferrer" className="hover:text-white"><i className="fab fa-whatsapp"></i></a>
                            <a href="https://github.com/miqueiasilva/site-studio-jacilene-felix" target="_blank" rel="noopener noreferrer" className="hover:text-white"><i className="fab fa-github"></i></a>
                        </div>
                    </div>
                    <div>
                        <h4 className="font-semibold mb-4">Serviços</h4>
                        <ul className="space-y-2 text-sm">
                            <li><a href="#" className="hover:text-white">Micropigmentação de Sobrancelhas</a></li>
                            <li><a href="#" className="hover:text-white">Micropigmentação Labial</a></li>
                            <li><a href="#" className="hover:text-white">Brow Lamination</a></li>
                            <li><a href="#" className="hover:text-white">Evolution Skin</a></li>
                            <li><a href="#" className="hover:text-white">Remoção</a></li>
                        </ul>
                    </div>
                     <div>
                        <h4 className="font-semibold mb-4">Links Úteis</h4>
                        <ul className="space-y-2 text-sm">
                            <li><a href="#" className="hover:text-white">Política de Privacidade</a></li>
                            <li><a href="#" className="hover:text-white">Termos de Uso</a></li>
                            <li><a href="#" className="hover:text-white">Política de Reagendamento</a></li>
                            <li><a href="#" className="hover:text-white">LGPD</a></li>
                        </ul>
                    </div>
                     <div>
                        <h4 className="font-semibold mb-4">Contato</h4>
                        <ul className="space-y-2 text-sm">
                            <li>R. Santina Gomes de Andrade, 04 - loja 04 - Centro</li>
                            <li>Igarassu - PE, 53610-272</li>
                            <li>(81) 99568-5910</li>
                            <li>contato@jacilenefelix.com.br</li>
                        </ul>
                    </div>
                </div>
                <div className="border-t border-[#5f493a] mt-8 pt-6 text-center text-sm">
                    <p className="flex items-center justify-center gap-1.5">
                        <span>&copy; 2024</span>
                        <img src="https://i.ibb.co/CsTQHWpN/Sem-T-tulo-1-removebg-preview.png" alt="Logo" className="h-4" loading="lazy" decoding="async" width="16" height="16" />
                        <span>Studio Jacilene Félix. Todos os direitos reservados.</span>
                    </p>
                    <p className="opacity-75">
                        Powered by Readdly | <a href="https://github.com/miqueiasilva/site-studio-jacilene-felix" target="_blank" rel="noopener noreferrer" className="underline hover:text-white">Ver código no GitHub</a>
                    </p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;