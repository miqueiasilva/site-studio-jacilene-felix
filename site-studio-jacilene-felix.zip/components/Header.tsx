
import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);

    const navItems = [
        { name: 'Home', href: '#home' },
        { name: 'Serviços', href: '#serviços' },
        { name: 'Profissionais', href: '#profissionais' },
        { name: 'Resultados', href: '#resultados' },
        { name: 'Contato', href: '#contato' }
    ];

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll, { passive: true });
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        if (isMenuOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';
        }
    }, [isMenuOpen]);

    const handleLinkClick = () => {
        setIsMenuOpen(false);
    };

    const headerClasses = `fixed top-0 left-0 right-0 z-40 transition-all duration-300 text-[#f9f6f2] ${
        isScrolled || isMenuOpen ? 'bg-[#3a322c] shadow-md' : 'bg-transparent'
    }`;

    return (
        <>
            <header className={headerClasses}>
                <div className="container mx-auto px-6 py-4 flex justify-between items-center">
                    <a href="#home" className="flex items-center gap-3">
                        <img src="https://i.ibb.co/CsTQHWpN/Sem-T-tulo-1-removebg-preview.png" alt="Studio Jacilene Félix Logo" className="h-10" />
                        <h1 className="text-2xl font-bold fancy-font">Studio Jacilene Félix</h1>
                    </a>
                    <nav className="hidden md:flex items-center space-x-8">
                        {navItems.map(item => (
                            <a key={item.name} href={item.href} className="hover:text-[#e9e2d9] transition-colors rounded focus:outline-none focus:ring-2 focus:ring-white">{item.name}</a>
                        ))}
                    </nav>
                    <a href="https://www.salao99.com.br/studio-jacilene-felix" target="_blank" rel="noopener noreferrer" className="hidden md:inline-block bg-[#745b47] text-white px-6 py-2 rounded-full hover:bg-[#5f493a] transition transform active:scale-95 focus:outline-none focus:ring-2 focus:ring-white">
                        Agendar Agora
                    </a>
                    <button
                        className="md:hidden text-2xl z-50 transition-transform active:scale-90"
                        onClick={() => setIsMenuOpen(!isMenuOpen)}
                        aria-controls="mobile-menu"
                        aria-expanded={isMenuOpen}
                        aria-label={isMenuOpen ? "Fechar menu" : "Abrir menu"}
                    >
                        <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
                    </button>
                </div>
            </header>
            {isMenuOpen && (
                <div id="mobile-menu" className="fixed inset-0 bg-[#3a322c] bg-opacity-95 z-30 flex flex-col items-center justify-center space-y-8 md:hidden">
                    {navItems.map(item => (
                        <a key={item.name} href={item.href} onClick={handleLinkClick} className="text-3xl fancy-font text-[#f9f6f2] hover:text-[#e9e2d9] transition-colors">
                            {item.name}
                        </a>
                    ))}
                     <a href="https://www.salao99.com.br/studio-jacilene-felix" target="_blank" rel="noopener noreferrer" className="mt-4 bg-[#745b47] text-white px-8 py-3 rounded-full hover:bg-[#5f493a] transition transform active:scale-95">
                        Agendar Agora
                    </a>
                </div>
            )}
        </>
    );
}

export default Header;
