
import React from 'react';

const Hero: React.FC = () => {
    return (
        <section id="home" className="relative h-screen flex items-center justify-center text-center text-[#f9f6f2] bg-[#3a322c]">
            {/* Background Image with Overlay */}
            <div className="absolute inset-0 z-0">
                <img 
                    src="https://i.ibb.co/XrtcD83R/Untitled-design-1.png" 
                    alt="Jacilene Félix realizando um procedimento" 
                    className="w-full h-full object-cover object-center opacity-40" 
                    width="1080"
                    height="1080"
                />
            </div>
            
            <div className="relative z-10 container mx-auto px-6 flex flex-col items-center">
                <h2 
                  className="text-5xl md:text-7xl font-bold fancy-font mb-4 leading-tight"
                  style={{ textShadow: '2px 2px 8px rgba(0,0,0,0.7)' }}
                >
                    Beleza Natural <br/> com Elegância
                </h2>
                <p 
                  className="mb-8 max-w-2xl text-lg text-[#e9e2d9]"
                  style={{ textShadow: '1px 1px 4px rgba(0,0,0,0.7)' }}
                >
                    Especialistas em micropigmentação e tratamentos estéticos que realçam sua beleza natural com técnicas avançadas e atendimento premium.
                </p>
                <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
                    <a href="https://www.salao99.com.br/studio-jacilene-felix" target="_blank" rel="noopener noreferrer" className="bg-[#745b47] text-white px-8 py-3 rounded-full hover:bg-[#5f493a] transition-transform hover:scale-105 active:scale-100 shadow-lg w-full sm:w-auto">
                        Agendar Agora
                    </a>
                    <a href="https://api.whatsapp.com/send/?phone=5581995685910" target="_blank" rel="noopener noreferrer" className="border-2 border-white text-white px-8 py-3 rounded-full hover:bg-white hover:text-[#3a322c] transition-transform active:scale-95 shadow-lg w-full sm:w-auto font-medium">
                        Falar com a IA no WhatsApp
                    </a>
                </div>
            </div>
        </section>
    );
}

export default Hero;
