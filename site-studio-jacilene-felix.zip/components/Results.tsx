
import React from 'react';
import { results } from '../constants';

const ResultCard: React.FC<{ result: typeof results[0], index: number }> = ({ result, index }) => {
    let imageClassName = 'w-full h-64 object-cover'; // Classe padrão

    // Aplica estilos de posicionamento de imagem com base no título para maior robustez
    if (result.title === 'Micropigmentação Natural') {
        imageClassName += ' object-[center_40%]';
    } else if (result.title === 'Lábios Revitalizados') {
        imageClassName += ' object-center';
    } else if (result.title === 'Sobrancelhas Perfeitas') {
        imageClassName += ' object-[center_40%]';
    }
    
    return (
        <div className="bg-[#e9e2d9] rounded-2xl overflow-hidden shadow-lg transition-transform hover:scale-105">
            <img src={result.image} alt={result.title} className={imageClassName} loading="lazy" decoding="async" width="400" height="256"/>
            <div className="p-6">
                <h3 className="text-xl font-bold fancy-font text-[#3a322c]">{result.title}</h3>
                <p className="text-sm text-[#745b47]">{result.description}</p>
            </div>
        </div>
    );
};

const Results: React.FC = () => {
    return (
        <section id="resultados" className="py-20 bg-[#f9f6f2]">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-bold fancy-font text-[#3a322c]">Resultados Reais</h2>
                    <p className="text-[#745b47] mt-2">Veja a transformação de nossas clientes e inspire-se com resultados naturais e duradouros</p>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {results.map((result, index) => (
                        <ResultCard key={index} result={result} index={index} />
                    ))}
                </div>
            </div>
        </section>
    );
}

export default Results;
