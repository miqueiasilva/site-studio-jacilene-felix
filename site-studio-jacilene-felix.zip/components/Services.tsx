
import React from 'react';
import { services } from '../constants';
import { Service } from '../types';

const ServiceCard: React.FC<{ service: Service }> = ({ service }) => {
    return (
        <div className="bg-white rounded-2xl overflow-hidden shadow-md transition-transform hover:scale-105 flex flex-col border border-gray-100">
            <div className="relative">
                <img src={service.image} alt={service.title} className="w-full h-56 object-cover" loading="lazy" decoding="async" width="400" height="224" />
                <div className="absolute top-3 right-3 bg-white/80 backdrop-blur-sm rounded-full w-8 h-8 flex items-center justify-center shadow">
                    <i className="far fa-clock text-gray-700"></i>
                </div>
            </div>
            <div className="p-5 flex flex-col flex-grow">
                <h3 className="text-lg font-bold text-gray-800">{service.title}</h3>
                {service.subtitle && <p className="text-sm font-semibold" style={{ color: '#e58a5b' }}>{service.subtitle}</p>}
                <p className="text-sm text-gray-600 mb-4 flex-grow">{service.description}</p>
                
                {service.tags && (
                    <div className="flex flex-wrap gap-2 mb-4">
                        {service.tags.map(tag => (
                            <span key={tag} className="bg-gray-100 text-gray-600 text-xs font-medium px-2.5 py-1 rounded-full">{tag}</span>
                        ))}
                    </div>
                )}

                {service.duration && (
                    <div className="text-sm text-gray-500 flex items-center mb-4">
                        <i className="far fa-clock mr-2"></i>
                        <span>Duração: {service.duration}</span>
                    </div>
                )}
                
                <div className="border-t border-gray-200 pt-4 mt-auto">
                    <p className="text-3xl font-bold text-gray-800 mb-1">R$ {service.price}</p>
                    {service.installments && <p className="text-xs text-gray-500">{service.installments}</p>}
                    {service.extra && <p className="text-xs text-gray-500">{service.extra}</p>}
                </div>

                <a href="https://www.salao99.com.br/studio-jacilene-felix" target="_blank" rel="noopener noreferrer" className="mt-4 block w-full bg-[#745b47] text-white text-center font-bold py-3 px-6 rounded-full hover:bg-[#5f493a] transition transform active:scale-95 shadow-md">
                    Agendar Consulta
                </a>
            </div>
        </div>
    );
};

const Services: React.FC = () => {
    return (
        <section id="serviços" className="py-20 bg-[#f9f6f2]">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-bold fancy-font text-[#3a322c]">Nossos Serviços</h2>
                    <p className="text-[#745b47] mt-2">Oferecemos tratamentos especializados em beleza e estética com técnicas modernas e resultados naturais</p>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {services.map((service, index) => (
                        <ServiceCard key={index} service={service} />
                    ))}
                </div>
            </div>
        </section>
    );
}

export default Services;
