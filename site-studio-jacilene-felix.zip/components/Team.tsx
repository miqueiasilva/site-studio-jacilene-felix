
import React from 'react';
import { teamMembers } from '../constants';
import { TeamMember } from '../types';

const TeamMemberCard: React.FC<{ member: TeamMember }> = ({ member }) => {
    const imageClassName = `w-full h-80 object-cover ${
        member.name === 'Jéssica Félix'
            ? 'object-[center_30%]' // Ajuste fino para Jéssica
            : member.name === 'Elda Priscila'
            ? 'object-top' // Ajuste para Elda
            : member.name === 'Graziela Oliveira'
            ? 'object-[center_25%]' // Ajuste para Graziela
            : member.name === 'Herlon Gonçalves'
            ? 'object-[center_20%]' // Ajuste para Herlon
            : member.name === 'Gleizia Santos'
            ? 'object-[center_35%]' // Alinhamento ajustado para Gleizia
            : 'object-center' // Padrão para os outros
    }`;

    return (
        <div className="bg-[#fffbf5] rounded-xl overflow-hidden shadow-lg transition-transform hover:scale-[1.02] flex flex-col">
            <img src={member.image} alt={member.name} className={imageClassName} loading="lazy" decoding="async" width="400" height="320" />
            <div className="p-6 flex flex-col flex-grow text-left">
                <h3 className="text-2xl font-bold fancy-font text-[#3a322c] mb-1">{member.name}</h3>
                <p style={{ color: '#e58a5b' }} className="font-semibold mb-3">{member.role}</p>
                <p className="text-sm text-[#745b47] mb-4">{member.bio}</p>
                
                <h4 className="font-semibold text-sm text-[#3a322c] mb-2">Especialidades:</h4>
                <div className="flex flex-wrap gap-2 mb-4">
                    {member.tags.map(tag => (
                        <span key={tag} className="bg-[#f3eee9] text-[#745b47] text-xs font-medium px-3 py-1 rounded-full">{tag}</span>
                    ))}
                </div>

                <div className="mt-auto pt-3 flex items-center text-sm text-[#745b47]">
                    <i className="far fa-clock mr-2"></i>
                    <span>Experiência: {member.experience}</span>
                </div>
            </div>
        </div>
    );
};

const Team: React.FC = () => {
    return (
        <section id="profissionais" className="py-20 bg-[#f9f6f2]">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-4xl md:text-5xl font-bold fancy-font text-[#3a322c]">Nossa Equipe</h2>
                    <p className="text-[#745b47] mt-2">Conheça nossos profissionais especializados em beleza e estética</p>
                </div>
                <div className="max-w-7xl mx-auto">
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {teamMembers.map((member, index) => (
                            <TeamMemberCard key={index} member={member} />
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Team;
