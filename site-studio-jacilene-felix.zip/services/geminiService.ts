
import { GoogleGenAI, GenerateContentResponse, Chat, Modality, Type, GenerateVideosOperation, VideosOperation } from "@google/genai";

const getAIClient = () => {
    return new GoogleGenAI({ apiKey: process.env.API_KEY as string });
};


// --- CHAT & GROUNDING ---
export const startChat = (systemInstruction: string): Chat => {
    return getAIClient().chats.create({
        model: 'gemini-2.5-flash',
        config: { systemInstruction },
    });
};

export const sendMessageToChat = async (chat: Chat, message: string): Promise<GenerateContentResponse> => {
    return await chat.sendMessage({ message });
};

export const generateGroundedResponse = async (prompt: string, tool: 'googleSearch' | 'googleMaps', location?: { latitude: number, longitude: number }): Promise<GenerateContentResponse> => {
    const config: any = {
        tools: tool === 'googleSearch' ? [{ googleSearch: {} }] : [{ googleMaps: {} }],
    };
    if (tool === 'googleMaps' && location) {
        config.toolConfig = {
            retrievalConfig: {
                latLng: location,
            }
        };
    }
    return getAIClient().models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config,
    });
};


// --- IMAGE SERVICES ---
export const generateImage = async (prompt: string, aspectRatio: string): Promise<string> => {
    const response = await getAIClient().models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt,
        config: {
            numberOfImages: 1,
            outputMimeType: 'image/jpeg',
            aspectRatio,
        },
    });
    const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
    return `data:image/jpeg;base64,${base64ImageBytes}`;
};

export const analyzeImage = async (base64Image: string, mimeType: string, prompt: string): Promise<string> => {
    const response = await getAIClient().models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                { inlineData: { data: base64Image, mimeType } },
                { text: prompt },
            ],
        },
    });
    return response.text;
};


// --- VIDEO SERVICES ---
export const generateVideoFromImage = async (base64Image: string, mimeType: string, prompt: string, aspectRatio: '16:9' | '9:16'): Promise<GenerateVideosOperation> => {
    const aiClient = getAIClient();
    return await aiClient.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt,
        image: {
            imageBytes: base64Image,
            mimeType,
        },
        config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio,
        }
    });
};

export const checkVideoOperationStatus = async (operation: GenerateVideosOperation | VideosOperation): Promise<VideosOperation> => {
    const aiClient = getAIClient();
    return await aiClient.operations.getVideosOperation({ operation });
};


// --- COMPLEX TASKS ---
export const getComplexConsultation = async (prompt: string): Promise<string> => {
    const response = await getAIClient().models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
            thinkingConfig: { thinkingBudget: 32768 }
        }
    });
    return response.text;
};


// --- AUDIO SERVICES ---
export const textToSpeech = async (text: string): Promise<string> => {
    const response = await getAIClient().models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say with a calm and professional tone: ${text}` }] }],
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: 'Kore' },
                },
            },
        },
    });
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) throw new Error("No audio generated");
    return base64Audio;
};
